#ifndef TRANSFORMA_H
#define TRANSFORMA_H

#include "afnd.h"
AFND * AFNDTransforma(AFND * afnd);

#endif
